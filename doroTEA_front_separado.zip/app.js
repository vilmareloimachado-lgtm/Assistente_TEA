
const LOGO = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="18 16 318 88" role="img" aria-label="doroTEA" style="width:min(280px,85%);height:auto;display:block;margin:0 auto"><g stroke="#fff" stroke-width="2.5" stroke-linejoin="round">
    <path d="M26.00 22.00 L64.00 22.00 L64.00 35.93 A6.33 6.33 0 1 1 64.00 46.07 L64.00 60.00 L50.07 60.00 A6.33 6.33 0 1 0 39.93 60.00 L26.00 60.00 L26.00 22.00Z" fill="#1e88e5"/>
    <path d="M64.00 22.00 L102.00 22.00 L102.00 60.00 L88.07 60.00 A6.33 6.33 0 1 1 77.93 60.00 L64.00 60.00 L64.00 46.07 A6.33 6.33 0 1 0 64.00 35.93 L64.00 22.00Z" fill="#e8453c"/>
    <path d="M26.00 60.00 L39.93 60.00 A6.33 6.33 0 1 1 50.07 60.00 L64.00 60.00 L64.00 73.93 A6.33 6.33 0 1 0 64.00 84.07 L64.00 98.00 L26.00 98.00 L26.00 60.00Z" fill="#fbc02d"/>
    <path d="M64.00 60.00 L77.93 60.00 A6.33 6.33 0 1 0 88.07 60.00 L102.00 60.00 L102.00 98.00 L64.00 98.00 L64.00 84.07 A6.33 6.33 0 1 1 64.00 73.93 L64.00 60.00Z" fill="#43a047"/>
  </g>
  <path d="M134.89712742450283 78.10655536459612Q132.62116376135526 78.10655536459612 130.52221949423028 77.12030444389885Q128.42327522710534 76.13405352320157 126.80481217775596 74.36385956297569Q125.18634912840658 72.59366560274981 124.25067517800147 70.29241345445617Q123.31500122759637 67.99116130616252 123.31500122759637 65.41173582126197Q123.31500122759637 62.93346427694574 124.25067517800147 60.68278909894427Q125.18634912840658 58.4321139209428 126.83010066290203 56.687208445863Q128.4738521973975 54.9423029707832 130.54750797937638 53.930763564939845Q132.62116376135526 52.91922415909649 134.89712742450283 52.91922415909649Q137.3248219985269 52.91922415909649 139.1961698993371 53.88018659464768Q140.20770930518046 54.43653326786153 141.0675178001473 55.245764792536214V45.23152467468696Q141.0675178001473 44.27056223913577 141.19396022587773 43.38546525902284Q141.32040265160816 42.500368278909896 142.0790572059907 41.94402160569605Q142.8377117603732 41.3876749324822 144.7090596611834 41.3876749324822Q146.5804075619936 41.3876749324822 147.36435060152223 41.91873312054996Q148.14829364105083 42.449791308617726 148.3253130370734 43.30959980358458Q148.502332433096 44.16940829855144 148.502332433096 45.1809477043948V74.31328259268352Q148.502332433096 75.27424502823472 148.3253130370734 76.15934200834766Q148.14829364105083 77.0444389884606 147.36435060152223 77.60078566167445Q146.5804075619936 78.15713233488829 144.75963663147556 78.15713233488829Q143.04001964154185 78.15713233488829 142.180211146575 77.60078566167445Q141.32040265160816 77.0444389884606 141.0675178001473 75.88116867174072V75.7800147311564Q140.2582862754726 76.53866928553892 139.29732383992143 77.0444389884606Q137.42597593911123 78.10655536459612 134.89712742450283 78.10655536459612ZM135.9086668303462 70.62116376135526Q137.2742450282347 70.62116376135526 138.36164988951631 69.938374662411Q139.44905475079793 69.25558556346672 140.1318438497422 68.09231524674686Q140.81463294868647 66.929044930027 140.81463294868647 65.51288976184631Q140.81463294868647 64.04615762337343 140.15713233488827 62.90817579179965Q139.4996317210901 61.770193960225875 138.3869383746624 61.11269334642769Q137.2742450282347 60.45519273262951 135.858089860054 60.45519273262951Q134.49251166216547 60.45519273262951 133.3545298305917 61.11269334642769Q132.21654799901793 61.770193960225875 131.58433587036583 62.90817579179965Q130.95212374171373 64.04615762337343 130.95212374171373 65.51288976184631Q130.95212374171373 66.929044930027 131.60962435551193 68.09231524674686Q132.2671249693101 69.25558556346672 133.43039528602995 69.938374662411Q134.5936656027498 70.62116376135526 135.9086668303462 70.62116376135526Z" fill="#4f555b"/>
  <path d="M164.78811686717407 78.56174809722563Q162.4109992634422 78.56174809722563 160.05917014485638 77.62607414682051Q157.70734102627057 76.69040019641541 155.7854161551682 74.97078320648171Q153.86349128406582 73.251166216548 152.7507979376381 70.84876012767002Q151.6381045912104 68.44635403879204 151.6381045912104 65.51288976184631Q151.6381045912104 62.78173336606923 152.64964399705377 60.42990424748342Q153.66118340289714 58.078075128897616 155.48195433341516 56.25730419837957Q157.3027252639332 54.43653326786153 159.65455438251902 53.399705376872085Q162.00638350110484 52.36287748588264 164.68696292658973 52.36287748588264Q168.32850478762583 52.36287748588264 171.28725754971765 54.10778296096244Q174.24601031180947 55.85268843604223 176.01620427203534 58.83672968328014Q177.78639823226123 61.820770930518044 177.78639823226123 65.46231279155414Q177.78639823226123 68.54750797937638 176.64841640068744 70.94991406825436Q175.51043456911367 73.35232015713234 173.61379818315737 75.07193714706605Q171.71716179720107 76.79155413699975 169.41590964890744 77.6766511171127Q167.11465750061382 78.56174809722563 164.78811686717407 78.56174809722563ZM164.68696292658973 70.92462558310827Q165.90081021360177 70.92462558310827 167.16523447090597 70.31770193960224Q168.42965872821017 69.71077829609624 169.28946722317704 68.49693100908421Q170.14927571814388 67.28308372207218 170.14927571814388 65.41173582126197Q170.14927571814388 63.7932727719126 169.44119813405354 62.57942548490057Q168.7331205499632 61.36557819788853 167.49398477780505 60.68278909894427Q166.25484900564695 60.0 164.63638595629757 60.0Q163.11907684753254 60.0 161.9305180456666 60.70807758409035Q160.74195924380064 61.4161551681807 160.0085931745642 62.655290940338816Q159.27522710532776 63.89442671249693 159.27522710532776 65.46231279155414Q159.27522710532776 67.28308372207218 160.10974711514854 68.52221949423028Q160.94426712496931 69.7613552663884 162.2086913822735 70.34299042474834Q163.4731156395777 70.92462558310827 164.68696292658973 70.92462558310827Z" fill="#4f555b"/>
  <path d="M184.71544316228824 78.15713233488829Q182.84409526147803 78.15713233488829 182.0601522219494 77.62607414682051Q181.2762091824208 77.09501595875275 181.09918978639823 76.18463049349373Q180.92217039037564 75.27424502823472 180.92217039037564 74.31328259268352V56.661919960716915Q180.92217039037564 55.65038055487356 181.12447827154432 54.7905720599067Q181.326786152713 53.930763564939845 182.1107291922416 53.39970537687208Q182.8946722317702 52.86864718880432 184.7660201325804 52.86864718880432Q186.5362140928063 52.86864718880432 187.32015713233488 53.349128406579915Q188.10410017186348 53.82960962435551 188.30640805303216 54.43653326786153Q188.4075619936165 54.7905720599067 188.45813896390865 55.09403388165971Q188.91333169653817 54.58826417873803 189.6214092806285 53.981340535232015Q190.38006383501104 53.42499386201817 191.46746869629266 53.020378099680826Q192.55487355757427 52.61576233734348 193.97102872575496 52.61576233734348Q194.52737539896881 52.61576233734348 195.21016449791307 52.69162779278173Q195.89295359685735 52.767493248219985 196.6263196660938 52.995089614534734Q197.35968573533023 53.22268598084949 197.96660937883624 53.602013258040756Q198.57353302234225 53.981340535232015 198.9528602995335 54.53768720844586Q199.33218757672478 55.09403388165971 199.33218757672478 55.9032654063344Q199.33218757672478 57.976921188313284 198.37122514117357 59.41836484164007Q197.4102627056224 60.859808494966856 195.9435305671495 60.859808494966856Q195.08372207218267 60.859808494966856 194.7296832801375 60.70807758409035Q194.37564448809232 60.556346673213845 194.14804812177755 60.40461576233734Q193.9204517554628 60.252884851460834 193.6169899337098 60.12644242573042Q193.31352811195677 60.0 192.50429658728208 60.0Q191.74564203289958 60.0 191.0628529339553 60.20230788116867Q190.38006383501104 60.40461576233734 189.7984286766511 60.83452000982077Q189.21679351829118 61.2644242573042 188.88804321139207 61.8966363859563Q188.559292904493 62.5288485146084 188.559292904493 63.287503068990915V74.41443653326786Q188.559292904493 75.37539896881906 188.3822735084704 76.26049594893199Q188.20525411244782 77.14559292904492 187.39602258777313 77.6513626319666Q186.58679106309845 78.15713233488829 184.71544316228824 78.15713233488829Z" fill="#4f555b"/>
  <path d="M214.45470169408298 78.56174809722563Q212.0775840903511 78.56174809722563 209.7257549717653 77.62607414682051Q207.3739258531795 76.69040019641541 205.4520009820771 74.97078320648171Q203.53007611097473 73.251166216548 202.41738276454703 70.84876012767002Q201.30468941811932 68.44635403879204 201.30468941811932 65.51288976184631Q201.30468941811932 62.78173336606923 202.3162288239627 60.42990424748342Q203.32776822980605 58.078075128897616 205.1485391603241 56.25730419837957Q206.96931009084213 54.43653326786153 209.32113920942794 53.399705376872085Q211.67296832801375 52.36287748588264 214.35354775349865 52.36287748588264Q217.99508961453475 52.36287748588264 220.95384237662657 54.10778296096244Q223.9125951387184 55.85268843604223 225.68278909894428 58.83672968328014Q227.45298305917015 61.820770930518044 227.45298305917015 65.46231279155414Q227.45298305917015 68.54750797937638 226.31500122759638 70.94991406825436Q225.1770193960226 73.35232015713234 223.2803830100663 75.07193714706605Q221.38374662411 76.79155413699975 219.08249447581636 77.6766511171127Q216.7812423275227 78.56174809722563 214.45470169408298 78.56174809722563ZM214.35354775349865 70.92462558310827Q215.5673950405107 70.92462558310827 216.8318192978149 70.31770193960224Q218.0962435551191 69.71077829609624 218.95605205008593 68.49693100908421Q219.8158605450528 67.28308372207218 219.8158605450528 65.41173582126197Q219.8158605450528 63.7932727719126 219.10778296096242 62.57942548490057Q218.39970537687208 61.36557819788853 217.16056960471397 60.68278909894427Q215.92143383255586 60.0 214.3029707832065 60.0Q212.78566167444146 60.0 211.5971028725755 60.70807758409035Q210.40854407070955 61.4161551681807 209.6751780014731 62.655290940338816Q208.94181193223667 63.89442671249693 208.94181193223667 65.46231279155414Q208.94181193223667 67.28308372207218 209.77633194205745 68.52221949423028Q210.61085195187823 69.7613552663884 211.87527620918243 70.34299042474834Q213.13970046648663 70.92462558310827 214.35354775349865 70.92462558310827Z" fill="#4f555b"/>
  <path d="M256.93935673950403 42.75325313037073Q257.79916523447093 42.75325313037073 258.5072428185613 42.90498404124723Q259.2153204026516 43.05671495212374 259.69580162042723 43.73950405106801Q260.1762828382028 44.42229315001227 260.1762828382028 46.091333169653815Q260.1762828382028 47.659219248711025 259.69580162042723 48.36729683280137Q259.2153204026516 49.07537441689172 258.4566658482691 49.22710532776823Q257.69801129388657 49.37883623864474 256.8382027989197 49.37883623864474H248.69531058188068V74.41443653326786Q248.69531058188068 75.37539896881906 248.5182911858581 76.23520746378591Q248.3412717898355 77.09501595875275 247.5573287503069 77.62607414682051Q246.77338571077829 78.15713233488829 244.90203780996808 78.15713233488829Q243.08126687945003 78.15713233488829 242.27203535477534 77.62607414682051Q241.46280383010065 77.09501595875275 241.31107291922416 76.20991897863982Q241.15934200834766 75.32482199852689 241.15934200834766 74.36385956297569V49.37883623864474H232.91529585072428Q232.1060643260496 49.37883623864474 231.34740977166706 49.20181684262215Q230.58875521728456 49.02479744659956 230.13356248465504 48.342008347655295Q229.67836975202553 47.659219248711025 229.67836975202553 46.04075619936165Q229.67836975202553 44.42229315001227 230.13356248465504 43.73950405106801Q230.58875521728456 43.05671495212374 231.34740977166706 42.90498404124723Q232.1060643260496 42.75325313037073 232.91529585072428 42.75325313037073Z" fill="#f774b2"/>
  <path d="M267.66167444144367 78.15713233488829Q265.8409035109256 78.15713233488829 265.0316719862509 77.62607414682051Q264.22244046157624 77.09501595875275 264.0454210655537 76.18463049349373Q263.86840166953107 75.27424502823472 263.86840166953107 74.31328259268352V46.64767984286766Q263.86840166953107 44.42229315001227 264.7282101644979 43.613061625337586Q265.58801865946475 42.8038301006629 267.81340535232016 42.8038301006629H286.93150012275964Q287.943039528603 42.8038301006629 288.8028480235698 42.98084949668549Q289.6626565185367 43.15786889270807 290.2190031917505 43.96710041738277Q290.77534986496437 44.77633194205745 290.77534986496437 46.69825681315983Q290.77534986496437 48.51902774367788 290.2190031917505 49.32825926835257Q289.6626565185367 50.137490793027254 288.77755953842376 50.31451018904984Q287.8924625583108 50.49152958507243 286.88092315246746 50.49152958507243H271.5561011539406V57.01595875276209H281.97495703412716Q282.98649643997055 57.01595875276209 283.77043947949915 57.1676896636386Q284.55438251902774 57.3194205745151 285.0095752516572 58.027498158605454Q285.46476798428677 58.7355757426958 285.46476798428677 60.40461576233734Q285.46476798428677 61.972501841394546 285.0095752516572 62.68057942548489Q284.55438251902774 63.38865700957525 283.745150994353 63.54038792045175Q282.93591946967837 63.69211883132826 281.87380309354285 63.69211883132826H271.5561011539406V70.46943285047877H286.93150012275964Q287.943039528603 70.46943285047877 288.8028480235698 70.67174073164745Q289.6626565185367 70.87404861281611 290.2190031917505 71.65799165234472Q290.77534986496437 72.44193469187331 290.77534986496437 74.36385956297569Q290.77534986496437 76.18463049349374 290.2190031917505 76.99386201816843Q289.6626565185367 77.80309354284311 288.77755953842376 77.9801129388657Q287.8924625583108 78.15713233488829 286.88092315246746 78.15713233488829Z" fill="#f774b2"/>
  <path d="M326.9378836238645 72.79597348391849Q327.5448072673705 74.06039774122269 327.59538423766264 74.94549472133562Q327.6459612079548 75.83059170144857 327.0643260495949 76.51338080039284Q326.48269089123494 77.1961698993371 325.1676896636386 77.85367051313528Q323.1446108519519 78.81463294868647 322.0319175055242 78.4353056714952Q320.9192241590965 78.05597839430395 319.9582617235453 76.03289958261723L317.02479744659956 69.91308617726492H303.1161306162534L300.1826663393076 76.03289958261723Q299.1711269334643 78.00540142401178 298.0837220721827 78.38472870120304Q296.99631721090105 78.7640559783943 294.9732383992143 77.80309354284311Q293.658237171618 77.1961698993371 293.076602013258 76.51338080039284Q292.4949668548981 75.83059170144857 292.5455438251903 74.89491775104347Q292.5961207954824 73.95924380063835 293.25362140928064 72.69481954333415L306.5553645961208 45.02921679351829Q307.06113429904246 44.01767738767493 308.04738521973974 43.410753744168915Q309.033636140437 42.8038301006629 310.09575251657253 42.8038301006629Q310.85440707095506 42.8038301006629 311.5119076847533 43.08200343726982Q312.16940829855145 43.360176773876745 312.70046648661923 43.86594647679843Q313.23152467468697 44.37171617972011 313.58556346673214 45.07979376381046ZM313.88902528848513 63.38865700957525 310.0451755462804 55.296341762828376 306.2013258040756 63.38865700957525Z" fill="#f774b2"/></svg>`;
const API="http://127.0.0.1:8000",$=s=>document.querySelector(s),esc=t=>String(t??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])),pct=(a,b)=>b?Math.round(a/b*100):0,br=d=>d?d.split("-").reverse().join("/"):"",iso=d=>d?d.split("/").reverse().join("-"):"",v=id=>$("#"+id)?.value.trim()||"";
const ld=k=>{try{return localStorage.getItem(k)}catch{return null}},sv=(k,x)=>{try{x==null?localStorage.removeItem(k):localStorage.setItem(k,x)}catch{}};
const IC={mic:'<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',logout:'<path d="M14 4h5v16h-5M15 12H3M7 8l-4 4 4 4"/>',back:'<path d="M15 5l-7 7 7 7"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',plus:'<path d="M12 5v14M5 12h14"/>',more:'<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',edit:'<path d="M4 20h4l11-11-4-4L4 16z"/>',trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',home:'<path d="M4 11l8-7 8 7v9H4z"/>',list:'<path d="M9 6h11M9 12h11M9 18h11M4 6h1M4 12h1M4 18h1"/>',chart:'<path d="M5 20V10M12 20V4M19 20v-7"/>',chat:'<path d="M4 5h16v11H9l-5 4z"/>',spark:'<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/>',chev:'<path d="M6 9l6 6 6-6"/>',ok:'<path d="M5 12l5 5 9-10"/>'};
const ic=(n,s=18)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n]}</svg>`;
const S={token:ld("t"),tipo:ld("tp"),pid:+ld("u")||null,nome:ld("n")||"",email:ld("em")||"",view:"login",perfis:[],tarefas:[],dash:null,cuid:[],chat:[],ab:new Set(),sug:{},processando:new Set(),filtro:"todas",edit:null};
const PR={baixa:"Baixa",media:"Média",alta:"Alta"},mgr=()=>S.tipo==="cuidador",P=()=>S.perfis.find(p=>p.usuario_id===S.pid)||{};
const mensagem={texto:"",tipo:"info"};
function blocoAviso(){return `<div id="aviso" class="${mensagem.texto?"on":""} ${mensagem.tipo}" role="${mensagem.tipo==="erro"?"alert":"status"}" aria-live="polite">${mensagem.texto?`<span class="texto">${esc(mensagem.texto)}</span><button type="button" data-a="fecharaviso" aria-label="Fechar mensagem">×</button>`:""}</div>`}
function atualizarAviso(){const a=$("#aviso");if(a)a.outerHTML=blocoAviso()}
function aviso(t,tipo="info"){if(!t||(tipo!=="erro"&&mensagem.tipo==="erro"&&mensagem.texto))return;mensagem.texto=t;mensagem.tipo=tipo;atualizarAviso();$("#aviso")?.scrollIntoView({block:"nearest",behavior:"auto"})}
function limparAviso(){mensagem.texto="";mensagem.tipo="info";atualizarAviso()}

function guardar(){sv("t",S.token);sv("tp",S.tipo);sv("u",S.tipo==="usuario_tea"?S.pid:null);sv("n",S.nome);sv("em",S.email)}
function sair(m){pararLeitura();Object.assign(S,{token:null,tipo:null,pid:null,nome:"",perfis:[],tarefas:[],chat:[],cuid:[],dash:null,ab:new Set(),sug:{},processando:new Set(),edit:null,filtro:"todas",view:"login"});guardar();render();aviso(m)}
async function api(p,o={}){let r;const controle=new AbortController(),limite=setTimeout(()=>controle.abort(),o.timeout||30000);try{r=await fetch(API+p,{signal:controle.signal,method:o.m||"GET",headers:{"Content-Type":"application/json",...(S.token?{Authorization:"Bearer "+S.token}:{})},body:o.b?JSON.stringify(o.b):undefined})}catch(e){throw new Error(e.name==="AbortError"?"O servidor demorou para responder. Verifique se a API está ligada e tente novamente.":"Não consegui falar com o servidor. A API está ligada?")}finally{clearTimeout(limite)}
let d=null;try{d=await r.json()}catch{}
if(!r.ok){if(r.status===401&&S.token&&!p.startsWith("/auth")){sair("Sua sessão acabou. Entre de novo.");throw new Error("")}{const er=new Error(typeof d?.detail==="string"?d.detail:"Algo deu errado. Tente de novo.");er.status=r.status;throw er}}return d}
// janelinhas: pergunta (com ou sem campo) e lista de opções
function ask({t,p="",ph="",ok="Confirmar",danger=0,inp=0,ty="password",confirmar=null}){
  return new Promise(res=>{
    const o=document.createElement("div");o.className="ov";
    o.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(t)}"><b>${esc(t)}</b><span class="mut">${esc(p)}</span>${inp?`<input id="ai" type="${ty}" placeholder="${esc(ph)}" autocomplete="off">`:""}<p class="sheet-error" role="alert" hidden></p><div class="row" style="justify-content:flex-end;margin-top:6px"><button type="button" class="btn" id="an">Cancelar</button><button type="button" class="btn ${danger?"rd":"pk"}" id="ay">${ok}</button></div></div>`;
    document.body.append(o);
    const i=o.querySelector("#ai"),cancelar=o.querySelector("#an"),salvar=o.querySelector("#ay"),erro=o.querySelector('.sheet-error');
    let ocupado=false;
    const fechar=x=>{o.remove();res(x)};
    (i||cancelar).focus();
    cancelar.onclick=()=>{if(!ocupado)fechar(null)};
    salvar.onclick=async()=>{
      if(ocupado)return;
      const valor=i?i.value:true;
      if(!confirmar){fechar(valor);return}
      ocupado=true;salvar.disabled=true;cancelar.disabled=true;
      salvar.setAttribute('aria-busy','true');salvar.textContent='Salvando…';erro.hidden=true;
      try{await confirmar(valor);fechar(valor)}
      catch(e){erro.textContent=e.message||'Não foi possível salvar. Tente novamente.';erro.hidden=false}
      finally{ocupado=false;salvar.disabled=false;cancelar.disabled=false;salvar.removeAttribute('aria-busy');salvar.textContent=ok;if(o.isConnected)salvar.focus()}
    };
    o.onclick=e=>{if(e.target===o&&!ocupado)fechar(null)};
    i?.addEventListener("keydown",e=>{
      if(e.key==="Enter"&&!e.isComposing){e.preventDefault();if(!e.repeat&&!ocupado)salvar.focus()}
    });
  });
}
function pick(t,its){return new Promise(res=>{const o=document.createElement("div");o.className="ov";o.innerHTML=`<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(t)}"><b>${esc(t)}</b>${its.map(([l,k,d])=>`<button class="btn ${d?"rd":""}" data-k="${k}">${l}</button>`).join("")}</div>`;document.body.append(o);o.onclick=e=>{const b=e.target.closest("[data-k]");if(b||e.target===o){o.remove();res(b?b.dataset.k:null)}};o.querySelector("button").focus()})}
// peças de tela
const head=(t,back)=>`<header>${back?`<button class="ib" data-a="go" data-v="${back}" aria-label="Voltar à tela anterior" title="Voltar para ${back==='perfis'?'Meus perfis':'Tarefas'}">${ic("back")}</button>`:mgr()&&S.view==="perfis"?`<button class="ib" data-a="sair" aria-label="Sair e voltar ao login" title="Sair e voltar ao login">${ic("back")}</button>`:'<span class="ib" style="visibility:hidden"></span>'}<div class="heading">${mgr()?`<div class="greeting">Olá, ${esc(S.nome.trim().split(/\s+/)[0]||"cuidador")} <span class="mode">· Modo cuidador</span></div>`:""}<h1>${esc(t)}</h1></div><button class="ib" data-a="menu" aria-label="Menu" title="Abrir menu">${ic("menu")}</button></header>`;
function nav(){const it=[...(mgr()?[["perfis","home","Perfis"]]:[]),["tarefas","list","Tarefas"],["dash","chart","Resumo"],["chat","chat","Chat IA"]];return `<nav aria-label="Principal">${it.map(([k,i,l])=>`<button data-a="go" data-v="${k}" class="${S.view===k?"on":""}" aria-label="${l}" title="Ir para ${l}"${S.view===k?' aria-current="page"':""}>${ic(i)}<span>${l}</span></button>`).join("")}</nav>`}
const fld=(id,l,val="",ty="text",x="")=>`<label for="${id}">${l}</label><input id="${id}" type="${ty}" value="${esc(val)}" ${x}>`;
const sel=(id,l,op,cur)=>`<label for="${id}">${l}</label><select id="${id}">${op.map(([k,n])=>`<option value="${k}"${k===cur?" selected":""}>${n}</option>`).join("")}</select>`;
const bar=(n,a,b)=>`<div style="margin-top:8px"><div class="row sp"><span>${n}</span><span class="mut">${a}/${b}</span></div><div class="bar" role="progressbar" aria-label="${n}" aria-valuenow="${pct(a,b)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct(a,b)}%"></i></div></div>`;
// telas
const V={
login:()=>`<main style="justify-content:center" data-go="#bl"><div style="margin:10px 0">${LOGO}</div><div class="card">${fld("e","Email",S.email,"email",'autocomplete="username"')}${fld("s","Senha","","password",'autocomplete="current-password"')}<div class="row" style="margin-top:14px"><button id="bl" class="btn pk grow" data-a="login">Entrar</button></div></div><button class="btn" style="align-self:center;border:0;background:none;color:#c2468a" data-a="go" data-v="conta">Criar conta de cuidador</button></main>`,
conta:()=>`<main data-nx><div style="margin:6px 0">${LOGO}</div><div class="card"><b>Criar conta de cuidador</b>${fld("nm","Seu nome")}${fld("e","Email","","email")}${fld("nc","Data de nascimento","","date")}${fld("s","Senha (mínimo 6)","","password",'autocomplete="new-password"')}<div class="row" style="margin-top:14px"><button class="btn grow" data-a="go" data-v="login">Voltar</button><button class="btn pk grow" data-a="criarconta">Criar conta</button></div></div></main>`,
perfis:()=>head("Meus perfis")+`<main><button class="btn pk" style="align-self:flex-start" data-a="go" data-v="pform">${ic("plus",15)} Novo perfil</button>${S.perfis.length?`<div class="grid">${S.perfis.map(p=>`<div class="card"><div class="row"><div class="av">${esc(p.nome[0]||"?").toUpperCase()}</div><div class="grow"><b>${esc(p.nome)}</b><div class="meta"><span class="chip pk">${p.principal?"Principal":"Apoio"}</span><span class="chip">${esc(p.nivel_suporte)}</span>${p.tem_pin?'<span class="chip">PIN</span>':""}</div></div><button class="ib" data-a="pm" data-id="${p.usuario_id}" aria-label="Mais opções de ${esc(p.nome)}">${ic("more")}</button></div><div class="row" style="margin-top:10px"><button class="btn dk grow" data-a="abrir" data-id="${p.usuario_id}">Abrir tarefas</button><button class="btn ol grow" data-a="entrar" data-id="${p.usuario_id}">Entrar como ${esc(p.nome.split(" ")[0])}</button></div></div>`).join("")}</div>`:'<div class="card"><b>Quer cadastrar um usuário TEA?</b><p class="mut">Toque em "Novo perfil".</p><p class="mut">Foi convidado a participar por um Cuidador/Responsável? Peça para ele adicionar o seu email como Apoio.</p></div>'}</main>`+nav(),
pform:()=>{const p=S.edit,n=!p;return head(n?"Novo perfil":"Editar perfil","perfis")+`<main data-nx><div class="card">${fld("nm","Nome",p?.nome)}${fld("nc","Data de nascimento",iso(p?.data_nascimento),"date")}${sel("nv","Nível de suporte",["Leve","Moderado","Severo"].map(x=>[x,x]),p?.nivel_suporte||"Leve")}${sel("es","Estilo das instruções",[["direto","Direto"],["detalhado","Detalhado"]],p?.estilo_instrucao||"direto")}${n?fld("pn","PIN (opcional)","","password",'inputmode="numeric" autocomplete="off"'):""}<div class="row" style="margin-top:14px"><button class="btn grow" data-a="go" data-v="perfis">Cancelar</button><button class="btn pk grow" data-a="salvarperfil">Salvar</button></div></div></main>`},
cuid:()=>{const p=P(),pr=p.principal;return head("Cuidadores de "+(p.nome||""),"perfis")+`<main data-go="#ba">${S.cuid.map(c=>`<div class="card"><div class="row"><div class="av">${esc(c.nome[0]||"?").toUpperCase()}</div><div class="grow"><b>${esc(c.nome)}</b><div class="mut">${esc(c.email||"")}</div><div class="meta"><span class="chip pk">${c.principal?"Principal":"Apoio"}</span></div></div></div>${pr&&!c.principal?`<div class="row" style="margin-top:8px"><button class="btn sm grow" data-a="tornar" data-id="${c.usuario_id}">Tornar principal</button><button class="btn sm rd" data-a="remcuid" data-id="${c.usuario_id}">Remover</button></div>`:""}</div>`).join("")}${pr?`<div class="card"><b>Adicionar Apoio</b><span class="mut"> (a pessoa precisa ter conta de cuidador)</span>${fld("ce","Email do Apoio","","email")}<button id="ba" class="btn pk" style="margin-top:10px" data-a="addcuid">Adicionar</button></div>`:'<p class="mut">Só o cuidador principal pode adicionar ou remover Apoios.</p>'}</main>`},
tarefas:()=>{const t=S.tarefas,ok=t.filter(x=>x.concluida).length,vis=t.filter(x=>S.filtro==="todas"||x.tipo===S.filtro);return head(mgr()?P().nome||"Tarefas":"Olá, "+S.nome.split(" ")[0],mgr()?"perfis":"")+`<main><div class="card"><div class="row sp"><span>${ok} de ${t.length} concluídas</span><b>${pct(ok,t.length)}%</b></div><div class="bar"><i style="width:${pct(ok,t.length)}%"></i></div></div><div class="row" style="flex-wrap:wrap"><button class="btn pk sm" data-a="go" data-v="tform">${ic("plus",14)} Nova</button>${[["todas","Todas"],["tarefas_diarias","Diárias"],["tarefas_educacionais","Educacionais"]].map(([k,l])=>`<button class="btn sm ${S.filtro===k?"dk":""}" data-a="filtro" data-id="${k}">${l}</button>`).join("")}</div>${vis.length?`<div class="grid">${vis.map(card).join("")}</div>`:'<p class="mut">Nenhuma tarefa aqui.</p>'}</main>`+nav()},
tform:()=>{const t=S.edit;return head(t?"Editar tarefa":"Nova tarefa","tarefas")+`<main data-nx><div class="card">${fld("ti","Título",t?.titulo)}${fld("de","Descrição",t?.descricao)}${t?"":sel("tp","Tipo",[["tarefas_diarias","Diária"],["tarefas_educacionais","Educacional"]],"tarefas_diarias")}${sel("pr","Prioridade",[["baixa","Baixa"],["media","Média"],["alta","Alta"]],t?.prioridade||"media")}${fld("pz","Prazo (opcional)",iso(t?.prazo),"date")}<div class="row" style="margin-top:14px"><button class="btn grow" data-a="go" data-v="tarefas">Cancelar</button><button class="btn pk grow" data-a="salvartarefa">Salvar</button></div></div></main>`},
dash:()=>{
  const d=S.dash,tp=d.por_tipo,pr=d.por_prioridade,total=d.total,concluidas=d.concluidas,percentual=pct(concluidas,total),circ=2*Math.PI*64;
  const prioridadeMax=Math.max(1,...["alta","media","baixa"].map(k=>pr[k].total));
  const barraTipo=(titulo,k)=>{const n=tp[k];return `<div class="dash-label"><span>${titulo}</span><span>${n.concluidas} de ${n.total}</span></div><div class="dash-track" role="img" aria-label="${titulo}: ${n.concluidas} de ${n.total} tarefas concluídas"><div class="dash-fill" style="width:${pct(n.concluidas,n.total)}%"></div></div>`};
  return head("Resumo",mgr()?"perfis":"")+`<main>
    <div class="card"><b>Conclusão das tarefas</b><div class="dash-ring-row">
      <svg class="dash-ring" viewBox="0 0 160 160" role="img" aria-label="${concluidas} de ${total} tarefas concluídas, ${percentual} por cento">
        <circle cx="80" cy="80" r="64" fill="none" stroke="#dce1e8" stroke-width="16"/>
        <circle cx="80" cy="80" r="64" fill="none" stroke="var(--pink)" stroke-width="16" stroke-dasharray="${circ*(total?concluidas/total:0)} ${circ}" transform="rotate(-90 80 80)"/>
        <text x="80" y="78" text-anchor="middle" fill="var(--ink)" style="font-size:28px;font-weight:600">${percentual}%</text>
        <text x="80" y="99" text-anchor="middle" fill="var(--mut)" style="font-size:12px">concluídas</text>
      </svg>
      <div class="dash-legend"><span><i class="dash-dot" style="background:var(--pink)"></i>${concluidas} concluídas</span><span><i class="dash-dot" style="background:#dce1e8"></i>${d.pendentes} pendentes</span></div>
    </div>${total?'':'<p class="dash-empty">Nenhuma tarefa cadastrada neste perfil.</p>'}</div>
    <div class="row"><div class="card grow"><div class="mut">Pendentes</div><b class="big">${d.pendentes}</b></div><div class="card grow"><div class="mut">Atrasadas</div><b class="big">${d.vencidas}</b><div class="mut">das pendentes</div></div></div>
    <div class="card"><b>Por tipo</b><div class="mut">Concluídas em relação ao total de cada tipo</div>${barraTipo("Diárias","tarefas_diarias")}${barraTipo("Educacionais","tarefas_educacionais")}<div class="dash-scale"><span>0%</span><span>50%</span><span>100%</span></div></div>
    <div class="card"><b>Por prioridade</b><div class="mut">Quantidade de tarefas</div>${["alta","media","baixa"].map(k=>`<div class="dash-label"><span>${PR[k]}</span><span>${pr[k].total} tarefa(s)</span></div><div class="dash-track" role="img" aria-label="Prioridade ${PR[k]}: ${pr[k].total} tarefas, ${pr[k].concluidas} concluídas"><div class="dash-fill" style="width:${100*pr[k].total/prioridadeMax}%;background:${k==='alta'?'#cf8b56':k==='media'?'var(--pink)':'#7f8995'}"></div></div><div class="mut" style="margin-top:4px">${pr[k].concluidas} concluída(s)</div>`).join("")}<div class="dash-scale"><span>0</span><span>Quantidade de tarefas</span><span>${total?prioridadeMax:0}</span></div></div>
    <div class="card"><b>Passos</b>${bar("Passos feitos",d.passos.concluidos,d.passos.total)}</div>
    </main>`+nav()
},
chat:()=>head("Chat com a IA",mgr()?"perfis":"")+`<main data-go="#bc" style="padding-bottom:4px">${S.chat.map(m=>`<div class="msg ${m.r}">${esc(m.t)}</div>`).join("")||'<p class="mut">Pergunte o que quiser.</p>'}</main><div class="row" style="padding:0 14px"><input id="q" placeholder="Escreva aqui" aria-label="Pergunta"><button id="bc" class="btn pk" data-a="enviar">Enviar</button></div>`+nav()
};
function card(t){
  const id=t.tarefa_id,ab=S.ab.has(String(id)),f=t.passos.filter(p=>p.concluido).length,busy=S.processando.has(String(id)),s=busy?null:S.sug[id];
  return `<article class="card">
    <div class="row"><button class="ib" type="button" data-a="ouvir" data-id="${id}" aria-label="Ouvir tarefa ${esc(t.titulo)}" title="Ouvir tarefa" aria-pressed="false">${ic("mic")}</button><button class="ck" role="checkbox" aria-checked="${t.concluida}" data-a="tt" data-id="${id}" aria-label="Concluir ${esc(t.titulo)}">${t.concluida?ic("ok",13):""}</button><div class="grow"><b class="${t.concluida?"rs":""}">${esc(t.titulo)}</b><div class="meta"><span class="chip pk">${PR[t.prioridade]}</span>${t.prazo?`<span class="chip">até ${esc(t.prazo)}</span>`:""}${t.passos.length?`<span class="chip">${f}/${t.passos.length} passos</span>`:""}</div></div><button class="ib" data-a="abrirt" data-id="${id}" aria-expanded="${ab}" aria-label="${ab?'Ocultar passos':'Mostrar passos'}" title="${ab?'Ocultar passos da tarefa':'Mostrar passos da tarefa'}">${ic("chev")}</button></div>
    ${t.descricao?`<div class="mut" style="margin-top:8px">${esc(t.descricao)}</div>`:""}
    ${busy?'<div class="ia-progress" role="status" aria-live="polite"><span class="spinner" aria-hidden="true"></span><span>A IA está preparando os passos… Aguarde.</span></div>':""}
    ${ab?`<div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">${t.passos.map(p=>`<div class="row"><button class="ib" type="button" data-a="ouvirpasso" data-id="${p.passo_id}" aria-label="Ouvir passo: ${esc(p.texto)}" title="Ouvir passo" aria-pressed="false">${ic("mic")}</button><button class="ck" role="checkbox" aria-checked="${p.concluido}" data-a="tp" data-id="${p.passo_id}">${p.concluido?ic("ok",13):""}</button><span class="grow ${p.concluido?"rs":""}">${esc(p.texto)}</span>${mgr()?`<button class="ib" style="width:28px;height:28px" data-a="delp" data-id="${p.passo_id}" aria-label="Excluir passo">${ic("trash",14)}</button>`:""}</div>`).join("")}
      ${s?`<div class="card" style="background:#fff"><b>Sugestão da IA</b>${s.map((x,i)=>`<div>${i+1}. ${esc(x)}</div>`).join("")}<div class="row" style="margin-top:8px;flex-wrap:wrap"><button class="btn pk sm" data-a="usar" data-id="${id}">Usar estes</button><button class="btn sm" data-a="sugerir" data-id="${id}">Outra</button><button class="btn sm" data-a="cancelarsug" data-id="${id}">Cancelar</button></div></div>`:""}
      <div class="row" style="flex-wrap:wrap"><button class="btn sm" data-a="addp" data-id="${id}">${ic("plus",14)} Adicionar passo</button><button class="btn sm" data-a="sugerir" data-id="${id}" ${busy?'disabled aria-busy="true"':""}>${ic("spark",14)} ${busy?"Gerando…":"Dividir com IA"}</button><button class="btn sm" data-a="edt" data-id="${id}">${ic("edit",14)} Editar</button>${mgr()?`<button class="btn sm rd" data-a="delt" data-id="${id}">${ic("trash",14)} Excluir</button>`:""}</div>
    </div>`:""}
  </article>`;
}
function render(){
  // A tela acompanha o tipo da sessão, inclusive após trocar de perfil.
  if(!S.token&&!['login','conta'].includes(S.view))S.view='login';
  if(S.token&&S.tipo==='usuario_tea'&&['login','conta','perfis','pform','cuid'].includes(S.view))S.view='tarefas';
  if(S.token&&S.tipo==='cuidador'&&['login','conta'].includes(S.view))S.view='perfis';
  const html=V[S.view]();
  $('#app').innerHTML=html.includes('</header>')?html.replace('</header>','</header>'+blocoAviso()):blocoAviso()+html;
  atualizarBotoesLeitura();
  const f=$('#app input');if(f&&['login','conta'].includes(S.view))f.focus();
}
async function go(k,x,perfilEscolhido=false){
  pararLeitura();
  const anterior=S.view,editAnterior=S.edit,tokenAnterior=S.token;
  limparAviso();
  try{
    if(!perfilEscolhido&&mgr()&&S.view==='perfis'&&['tarefas','dash','chat','tform'].includes(k)){
      if(!S.perfis.length)throw new Error('Cadastre um perfil em Novo perfil para acessar esta opção.');
      const escolhido=S.perfis.length===1?String(S.perfis[0].usuario_id):await pick('Escolha o perfil',S.perfis.map(p=>[esc(p.nome),String(p.usuario_id)]));
      if(escolhido===null)return false;
      const novoId=Number(escolhido);
      if(S.pid!==novoId){S.chat=[];S.tarefas=[];S.dash=null;S.ab=new Set();S.sug={};S.processando=new Set()}
      S.pid=novoId;
    }
    if(S.tipo==='usuario_tea'&&['perfis','pform','cuid'].includes(k))throw new Error('Esta opção é exclusiva do cuidador. Use o menu para voltar ao modo cuidador.');
    if(k==='perfis')S.perfis=(await api('/usuarios')).usuarios;
    if(k==='tarefas'){
      const r=await api('/tarefas/'+S.pid);
      if(!Array.isArray(r.dados))throw new Error('O servidor retornou uma lista de tarefas em formato inesperado.');
      S.tarefas=r.dados;
    }
    if(k==='dash')S.dash=await api(`/tarefas/${S.pid}/dashboard`);
    if(k==='cuid')S.cuid=(await api(`/usuarios/${S.pid}/cuidadores`)).cuidadores;
    S.view=k;S.edit=x||null;render();scrollTo(0,0);
  }catch(e){
    // Uma falha de rede não deve apagar os campos que a pessoa preencheu.
    if(S.token===tokenAnterior&&S.view!==anterior){S.view=anterior;S.edit=editAnterior;render()}
    aviso(e.message,'erro');return false;
  }
  return true;
}

const tarefa=id=>S.tarefas.find(t=>t.tarefa_id==id),run=async f=>{limparAviso();try{await f()}catch(e){aviso(e.message,"erro")}};
const entrada=d=>{
  pararLeitura();
  Object.assign(S,{token:d.token,tipo:d.tipo_usuario,nome:d.nome,pid:d.tipo_usuario==="usuario_tea"?d.usuario_id:null,view:d.tipo_usuario==="usuario_tea"?"tarefas":"perfis",perfis:[],tarefas:[],cuid:[],dash:null,chat:[],ab:new Set(),sug:{},processando:new Set(),edit:null});
  S.filtro="todas";guardar();limparAviso();render();
};
// Leitura em voz alta: utiliza a voz do aparelho e não solicita acesso ao microfone.
const leitura={id:null,fala:null};
function atualizarBotoesLeitura(){
  document.querySelectorAll('[data-a="ouvir"],[data-a="ouvirpasso"]').forEach(b=>{
    const passo=b.dataset.a==='ouvirpasso',chave=(passo?'passo:':'tarefa:')+b.dataset.id;
    const ativo=leitura.id===chave;
    b.setAttribute('aria-pressed',String(ativo));
    b.setAttribute('aria-label',ativo?'Parar leitura':passo?'Ouvir passo':'Ouvir texto da tarefa');
    b.title=ativo?'Parar leitura':passo?'Ouvir passo':'Ouvir tarefa';b.innerHTML=ic(ativo?'stop':'mic');
  });
}
function pararLeitura(){
  const tinhaFala=leitura.fala!==null;leitura.id=null;leitura.fala=null;
  if(tinhaFala&&'speechSynthesis' in window)window.speechSynthesis.cancel();
  atualizarBotoesLeitura();
}
function ouvirDescricao(id){
  const t=tarefa(id);ouvirTexto('tarefa:'+id,(t?.descricao||t?.titulo||'').trim());
}
function ouvirPasso(id){
  const p=S.tarefas.flatMap(t=>t.passos).find(p=>p.passo_id==id);
  ouvirTexto('passo:'+id,(p?.texto||'').trim());
}
function ouvirTexto(chave,texto){
  if(!S.token)return;
  if(!('speechSynthesis' in window)||!('SpeechSynthesisUtterance' in window)){aviso('Este navegador não oferece leitura em voz alta. Tente abrir no Chrome ou Edge.','erro');return}
  if(leitura.id===chave){pararLeitura();return}
  if(!texto){aviso('Não há texto para ouvir.');return}
  pararLeitura();limparAviso();
  const fala=new window.SpeechSynthesisUtterance(texto),sintese=window.speechSynthesis;
  const vozes=sintese.getVoices(),idioma=v=>v.lang.toLowerCase().replace('_','-');
  const voz=vozes.find(v=>idioma(v)==='pt-br')||vozes.find(v=>idioma(v).startsWith('pt'));
  fala.lang='pt-BR';if(voz)fala.voice=voz;fala.rate=.9;fala.pitch=1;fala.volume=1;
  leitura.id=chave;leitura.fala=fala;atualizarBotoesLeitura();
  fala.onend=()=>{if(leitura.fala===fala){leitura.id=null;leitura.fala=null;atualizarBotoesLeitura()}};
  fala.onerror=e=>{if(leitura.fala!==fala)return;leitura.id=null;leitura.fala=null;atualizarBotoesLeitura();if(!['canceled','interrupted'].includes(e.error))aviso('Não foi possível reproduzir a voz. Verifique as vozes em português e o áudio do aparelho.','erro')};
  try{sintese.speak(fala)}catch{pararLeitura();aviso('Não foi possível iniciar a leitura neste navegador.','erro')}
}

const A={
ouvir:d=>ouvirDescricao(d.id),
ouvirpasso:d=>ouvirPasso(d.id),
fecharaviso:()=>limparAviso(),
sair:()=>{limparAviso();sair()},
go:d=>go(d.v),filtro:d=>{S.filtro=d.id;render()},
login:()=>run(async()=>{const d=await api("/auth/login",{m:"POST",b:{email:v("e"),senha:v("s")}});S.email=v("e");entrada(d);go(S.tipo==="cuidador"?"perfis":"tarefas")}),
criarconta:()=>run(async()=>{await api("/usuarios/conta",{m:"POST",b:{nome:v("nm"),email:v("e"),senha:v("s"),data_nascimento:br(v("nc"))}});S.email=v("e");S.view="login";render();aviso("Conta criada! Agora é só entrar.")}),
menu:async()=>{const m=mgr(),k=await pick("Menu",m?[["Meus perfis","perfis"],["Excluir minha conta","conta",1],["Sair","sair"]]:[["Voltar ao modo cuidador","volta"],["Sair deste aparelho","desparear"]]);if(k==="perfis")go("perfis");if(k==="sair")sair();if(k==="volta")A.volta();if(k==="desparear")A.desparear();if(k==="conta")run(async()=>{const s=await ask({t:"Excluir sua conta?",p:"Digite sua senha. Isso não pode ser desfeito.",ph:"Senha",ok:"Excluir",danger:1,inp:1});if(!s)return;await api("/usuarios/conta",{m:"DELETE",b:{senha:s}});sair("Conta excluída.")})},
volta:()=>run(async()=>{const s=await ask({t:"Voltar ao modo cuidador",p:"Digite a senha do cuidador.",ph:"Senha",inp:1});if(!s)return;entrada(await api("/auth/login",{m:"POST",b:{email:S.email,senha:s}}));S.chat=[];go("perfis")}),
desparear:()=>run(async()=>{const s=await ask({t:"Sair deste aparelho",p:"Digite a senha do cuidador. Depois disso, só o cuidador consegue entrar de novo aqui.",ph:"Senha",ok:"Sair",danger:1,inp:1});if(!s)return;await api("/auth/login",{m:"POST",b:{email:S.email,senha:s}});sair("Aparelho desconectado.")}),
addp:d=>run(async()=>{const x=await ask({t:"Novo passo",p:"Escreva o que precisa ser feito neste passo.",ph:"Ex.: Guardar os cadernos",ok:"Salvar",inp:1,ty:"text",confirmar:async valor=>{const texto=valor.trim();if(!texto)throw new Error("Escreva o texto do passo antes de salvar.");if(texto.length>200)throw new Error("O passo pode ter no máximo 200 caracteres.");await api(`/tarefas/${d.id}/passos/novo`,{m:"POST",b:{texto}})}});if(x===null)return;await go("tarefas");aviso("Passo adicionado.")}),
abrir:d=>{if(S.pid!==+d.id){S.pid=+d.id;S.chat=[];S.tarefas=[];S.dash=null;S.ab=new Set();S.sug={};S.processando=new Set();S.filtro="todas"}return go("tarefas",null,true)},
entrar:d=>run(async()=>{const p=S.perfis.find(x=>x.usuario_id==d.id);let pin=null;if(p.tem_pin){pin=await ask({t:"PIN de "+p.nome,ph:"PIN",ok:"Entrar",inp:1});if(!pin)return}entrada(await api("/auth/entrar-perfil",{m:"POST",b:{usuario_id:+d.id,pin}}));S.pid=+d.id;S.chat=[];guardar();go("tarefas")}),
pm:async d=>{S.pid=+d.id;const p=P(),k=await pick(p.nome,[["Editar perfil","ed"],[p.tem_pin?"Trocar PIN":"Definir PIN","pin"],...(p.tem_pin?[["Remover PIN","rpin"]]:[]),["Cuidadores","cu"],...(p.principal?[["Excluir perfil","del",1]]:[])]);if(k==="ed")go("pform",p);if(k==="cu")go("cuid");if(k==="pin")run(async()=>{const n=await ask({t:"PIN de "+p.nome,ph:"Novo PIN",inp:1});if(!n)return;await api(`/usuarios/${p.usuario_id}/pin`,{m:"PUT",b:{pin:n}});go("perfis");aviso("PIN salvo.")});if(k==="rpin")run(async()=>{await api(`/usuarios/${p.usuario_id}/pin`,{m:"DELETE"});go("perfis");aviso("PIN removido.")});if(k==="del")run(async()=>{if(!await ask({t:"Excluir o perfil de "+p.nome+"?",p:"Apaga também as tarefas e passos. Não dá para desfazer.",ok:"Excluir",danger:1}))return;await api("/usuarios/"+p.usuario_id,{m:"DELETE"});go("perfis");aviso("Perfil excluído.")})},
salvarperfil:()=>run(async()=>{const e=S.edit,b={nome:v("nm"),estilo_instrucao:v("es"),nivel_suporte:v("nv"),data_nascimento:br(v("nc"))};if(e)await api("/usuarios/"+e.usuario_id,{m:"PUT",b});else await api("/usuarios",{m:"POST",b:{...b,pin:v("pn")||null}});await go("perfis");aviso("Perfil salvo.")}),
addcuid:()=>run(async()=>{const em=v("ce");if(!em)return aviso("Digite o email.");if(!await ask({t:"Dar acesso?",p:`${em} vai ver os dados de ${P().nome}.`,ok:"Adicionar"}))return;await api(`/usuarios/${S.pid}/cuidadores`,{m:"POST",b:{email:em}});await go("cuid");aviso("Apoio adicionado.")}),
remcuid:d=>run(async()=>{if(!await ask({t:"Remover este Apoio?",ok:"Remover",danger:1}))return;await api(`/usuarios/${S.pid}/cuidadores/${d.id}`,{m:"DELETE"});go("cuid")}),
tornar:d=>run(async()=>{if(!await ask({t:"Passar o papel de principal?",p:"Você passa a ser Apoio neste perfil.",ok:"Passar"}))return;await api(`/usuarios/${S.pid}/cuidador-principal`,{m:"PUT",b:{novo_principal_id:+d.id}});S.perfis=(await api("/usuarios")).usuarios;go("cuid")}),
abrirt:d=>{S.ab.has(d.id)?S.ab.delete(d.id):S.ab.add(d.id);render()},
tt:d=>run(async()=>{await api(`/tarefas/${d.id}/status`,{m:"PATCH"});go("tarefas")}),
tp:d=>run(async()=>{await api(`/passos/${d.id}/status`,{m:"PATCH"});go("tarefas")}),
delp:d=>run(async()=>{if(!await ask({t:"Excluir este passo?",ok:"Excluir",danger:1}))return;await api("/passos/"+d.id,{m:"DELETE"});go("tarefas")}),
delt:d=>run(async()=>{if(!await ask({t:"Excluir esta tarefa?",ok:"Excluir",danger:1}))return;await api("/tarefas/"+d.id,{m:"DELETE"});go("tarefas")}),
edt:d=>go("tform",tarefa(d.id)),
salvartarefa:()=>run(async()=>{const e=S.edit;if(e)await api("/tarefas/"+e.tarefa_id,{m:"PUT",b:{titulo:v("ti"),descricao:v("de"),prioridade:v("pr"),prazo:br(v("pz"))}});else await api("/tarefas/"+S.pid,{m:"POST",b:{titulo:v("ti"),descricao:v("de"),tipo:v("tp"),prioridade:v("pr"),prazo:br(v("pz"))}});if(!e)S.filtro="todas";await go("tarefas");aviso("Tarefa salva.")}),
cancelarsug:d=>{delete S.sug[d.id];limparAviso();render()},
sugerir:d=>run(async()=>{
  const id=String(d.id),pid=S.pid,token=S.token,pendentes=S.processando;
  if(pendentes.has(id))return;
  pendentes.add(id);delete S.sug[id];S.ab.add(id);render();
  try{
    const passos=(await api(`/ia/tarefas/${id}/sugerir-passos`,{m:"POST",timeout:90000})).passos;
    if(S.pid!==pid||S.token!==token)return;
    if(!Array.isArray(passos)||!passos.length)throw new Error('A IA não retornou passos. Tente gerar novamente.');
    S.sug[id]=passos;
  }catch(e){if(S.pid===pid&&S.token===token)throw e}
  finally{pendentes.delete(id);if(S.pid===pid&&S.token===token&&S.view==="tarefas")render()}
}),
usar:d=>run(async()=>{const t0=tarefa(d.id);if(t0&&t0.passos.length&&!await ask({t:"Trocar os passos?",p:"Os passos atuais serão substituídos por estes, e o que já foi marcado será perdido.",ok:"Trocar",danger:1}))return;await api(`/tarefas/${d.id}/passos`,{m:"POST",b:{textos:S.sug[d.id]}});delete S.sug[d.id];go("tarefas")}),
enviar:()=>run(async()=>{const q=v("q");if(!q)return;const pid=S.pid,token=S.token;S.chat.push({r:"me",t:q});render();const r=(await api(`/ia/${pid}/chat`,{m:"POST",b:{pergunta:q}})).respostas;if(S.pid!==pid||S.token!==token)return;S.chat.push({r:"ia",t:Array.isArray(r)?r.join("\n"):r});if(S.view==="chat"){render();$("#q")?.focus()}})
};
document.addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(b)A[b.dataset.a]?.(b.dataset)});
// Enter avança pelos campos; no último campo apenas coloca o foco em Salvar.
// Com o foco em um botão, o Enter mantém o comportamento normal do navegador.
document.addEventListener("keydown",e=>{
  if(e.key!=="Enter"||e.isComposing||e.target.closest(".ov"))return;
  const n=e.target.closest("[data-nx]");
  if(n){
    const f=[...n.querySelectorAll("input,select")],i=f.indexOf(e.target);
    if(i<0)return;
    e.preventDefault();
    const proximo=f[i+1]||n.querySelector('[data-a="salvartarefa"],[data-a="salvarperfil"],[data-a="criarconta"]');
    proximo?.focus();return;
  }
  const g=e.target.closest("[data-go]")||(e.target.id==="q"?document:null);
  if(g){e.preventDefault();(g===document?$("#bc"):g.querySelector(g.dataset.go))?.click()}
});
async function iniciar(){
  if(!S.token){render();return}
  $("#app").innerHTML='<main style="justify-content:center"><div class="card" role="status">Carregando sua sessão…</div></main>';
  // Criança: cada vez que o app abre, a sessão é renovada por mais 7 dias.
  if(S.tipo==="usuario_tea"){
    try{entrada(await api("/auth/renovar",{m:"POST"}))}
    catch(e){
      if(e.status===401||e.status===403){sair("Sua sessão acabou. Peça ao cuidador para entrar de novo neste aparelho.");return}
      aviso(e.message,"erro")
    }
  }
  await go(S.tipo==="cuidador"?"perfis":"tarefas");
  if(S.view==="login"||!$("#app").children.length)render();
}
iniciar().catch(e=>{S.view="login";render();aviso(e.message||"Não foi possível abrir sua sessão. Tente entrar novamente.","erro")});
